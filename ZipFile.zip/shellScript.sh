sleep 5
echo "delay of 1s"
sleep 1
echo "done"
echo "end of script"
touch /home/lucas/Desktop/endOfScriptProof.txt